import Phaser from 'phaser';
import { io, type Socket } from 'socket.io-client';
import './style.css';
import { WorldScene } from './game/WorldScene';
import type { ItemDef, ItemId, Job, PlayerNet } from './game/types';

const API = import.meta.env.VITE_SERVER_URL || 'http://localhost:3001';
const qs = <T extends Element = HTMLElement>(selector: string) => document.querySelector(selector) as T;
const $ = (selector: string) => qs<HTMLElement>(selector);
const clamp = (n: number, min = 0, max = 100) => Math.max(min, Math.min(max, n));

const JOB_ICON: Record<Job, string> = {
  Novice: '🧑',
  Swordsman: '⚔️',
  Mage: '🧙',
  Archer: '🏹',
};

type CharacterSummary = {
  id: string;
  name: string;
  job: Job;
  level: number;
};

type PartyState = {
  leaderId: string;
  members: Array<{ id: string; name: string; job: Job; level: number }>;
};

let game: Phaser.Game | undefined;
let socket: Socket | undefined;
let me: PlayerNet | undefined;
let items: Record<string, ItemDef> = {};
let token = '';
let characters: CharacterSummary[] = [];
let toastTimer = 0;

function toast(message: string) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => el.classList.remove('show'), 2200);
}

async function readJson(response: Response) {
  const json = await response.json();
  if (!response.ok) throw new Error(json.error || `HTTP ${response.status}`);
  return json;
}

async function auth(mode: 'login' | 'register') {
  const username = qs<HTMLInputElement>('#username').value.trim();
  const password = qs<HTMLInputElement>('#password').value;
  const name = qs<HTMLInputElement>('#charname').value.trim();
  const job = qs<HTMLSelectElement>('#job-select').value as Job;
  const status = $('#auth-status');

  if (!username || !password) {
    status.textContent = 'กรอกชื่อบัญชีและรหัสผ่านก่อน';
    return;
  }

  status.textContent = mode === 'register' ? 'กำลังสร้างบัญชี...' : 'กำลังเชื่อมต่อ Realms...';

  try {
    if (mode === 'register') {
      if (!name) throw new Error('กรอกชื่อตัวละครเริ่มต้นก่อนสมัครบัญชี');
      await readJson(
        await fetch(`${API}/api/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password, name, job }),
        }),
      );
    }

    const data = await readJson(
      await fetch(`${API}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      }),
    );

    token = data.token;
    characters = data.characters;
    status.textContent = 'เชื่อมต่อสำเร็จ';
    showCharacters();
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : 'เกิดข้อผิดพลาด';
  }
}

function showCharacters() {
  $('#login').classList.add('hidden');
  $('#characters').classList.remove('hidden');

  const grid = $('#character-grid');
  grid.innerHTML = characters
    .map(
      (character) => `
        <button class="item char job-${character.job.toLowerCase()}" data-char="${character.id}">
          <strong>${JOB_ICON[character.job]}</strong>
          <span>${character.name}</span>
          <small>${character.job} · Lv.${character.level}</small>
          <em>เข้าสู่โลก</em>
        </button>`,
    )
    .join('');

  grid.querySelectorAll<HTMLButtonElement>('[data-char]').forEach((button) => {
    button.onclick = () => connect(token, button.dataset.char!);
  });
}

async function createCharacter() {
  const name = qs<HTMLInputElement>('#new-char-name').value.trim();
  const job = qs<HTMLSelectElement>('#new-char-job').value as Job;
  if (!name) return toast('กรอกชื่อตัวละครก่อน');

  try {
    const data = await readJson(
      await fetch(`${API}/api/character`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, name, job }),
      }),
    );
    characters = data.characters;
    qs<HTMLInputElement>('#new-char-name').value = '';
    showCharacters();
    toast(`สร้าง ${name} สำเร็จ`);
  } catch (error) {
    toast(error instanceof Error ? error.message : 'สร้างตัวละครไม่สำเร็จ');
  }
}

function connect(authToken: string, characterId: string) {
  socket?.disconnect();
  socket = io(API, { auth: { token: authToken, characterId } });

  socket.on('connect', () => {
    if (game) return;
    $('#characters').classList.add('hidden');

    const world = new WorldScene();
    world.socket = socket!;
    world.selfId = socket!.id || '';

    game = new Phaser.Game({
      type: Phaser.AUTO,
      parent: 'game',
      width: innerWidth,
      height: innerHeight,
      backgroundColor: '#172017',
      physics: { default: 'arcade' },
      scene: [world],
      render: { antialias: true, pixelArt: false },
      scale: {
        mode: Phaser.Scale.RESIZE,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
    });
  });

  socket.on('connect_error', (error: Error) => toast(`เชื่อมต่อไม่ได้: ${error.message}`));
  socket.on('auth:error', (message: string) => toast(message));
  socket.on('online', (count: number) => ($('#online').textContent = String(count)));
  socket.on('items', (value: Record<string, ItemDef>) => {
    items = value;
    renderAll();
  });
  socket.on('shop', (shop: { items: ItemDef[] }) => renderShop(shop.items));
  socket.on('self', (player: PlayerNet) => {
    me = player;
    renderAll();
  });
  socket.on('toast', toast);
  socket.on('party', (party: PartyState | null) => renderParty(party));
  socket.on('party:invite', (invite: { from: string; partyId: string }) => {
    if (confirm(`${invite.from} เชิญเข้าปาร์ตี้ — รับหรือไม่?`)) {
      socket?.emit('party:accept', invite.partyId);
    }
  });
  socket.on('trade:offer', (offer: any) => {
    const itemLine = offer.item ? `${offer.item.icon} ${offer.item.name} x${offer.qty}` : '';
    const zenyLine = offer.zeny ? `${offer.zeny} Zeny` : '';
    const description = [itemLine, zenyLine].filter(Boolean).join('\n');
    if (confirm(`${offer.from} เสนอ Trade\n${description}\nรับหรือไม่?`)) {
      socket?.emit('trade:accept', offer.id);
    }
  });
  socket.on('chat', (message: { name: string; text: string }) => {
    const p = document.createElement('p');
    const who = document.createElement('b');
    who.textContent = `${message.name}: `;
    p.append(who, document.createTextNode(message.text));
    $('#messages').appendChild(p);
    $('#messages').scrollTop = $('#messages').scrollHeight;
  });
}

function renderAll() {
  if (!me) return;

  $('#name').textContent = me.name;
  $('#lv').textContent = `Lv.${me.level}`;
  $('#job-icon').textContent = JOB_ICON[me.job] || '🧑';
  $('#job').textContent = `${me.job} • Skill Points ${me.skillPoints}${me.dead ? ' • ☠ DEAD' : ''}`;
  $('#map').textContent = me.map === 'town' ? 'HOKADIW Town' : 'Poring Field';

  $('#hp').style.width = `${clamp((me.hp / me.maxHp) * 100)}%`;
  $('#mp').style.width = `${clamp((me.mp / me.maxMp) * 100)}%`;
  $('#exp').style.width = `${clamp((me.exp / (me.level * 100)) * 100)}%`;

  $('#stats').textContent = `HP ${me.hp}/${me.maxHp} • MP ${me.mp}/${me.maxMp} • EXP ${me.exp}/${me.level * 100} • ${me.zeny}z`;
  $('#combat').textContent = `ATK ${me.atk} • MATK ${me.matk} • DEF ${me.def}`;
  $('#quest').textContent = `กำจัด Poringling ${Math.min(5, me.kills)}/5`;

  document.body.classList.toggle('player-dead', Boolean(me.dead));
  renderInventory();
  renderSkills();
}

function renderInventory() {
  if (!me?.inventory) return;
  const equipment = me.equipment || {};
  const labels = {
    weapon: '⚔ อาวุธ',
    armor: '🛡 เกราะ',
    head: '🎩 ศีรษะ',
    accessory: '💍 เครื่องประดับ',
  } as const;

  $('#equipment').innerHTML = `
    <div class="equip">
      ${(['weapon', 'armor', 'head', 'accessory'] as const)
        .map((slot) => {
          const id = equipment[slot];
          const def = id ? items[id] : undefined;
          return `<span><small>${labels[slot]}</small><b>${id ? `${def?.icon || ''} ${def?.name || id}` : '—'}</b></span>`;
        })
        .join('')}
    </div>`;

  $('#inventory-grid').innerHTML = me.inventory
    .map(
      (row) => `
        <button class="item" data-item="${row.id}">
          <strong>${row.def.icon}</strong>
          <span>${row.def.name}</span>
          <small>x${row.qty}${row.def.atk ? ` · ATK +${row.def.atk}` : ''}${row.def.matk ? ` · MATK +${row.def.matk}` : ''}${row.def.def ? ` · DEF +${row.def.def}` : ''}</small>
        </button>`,
    )
    .join('');

  document.querySelectorAll<HTMLButtonElement>('[data-item]').forEach((button) => {
    button.onclick = () => {
      const id = button.dataset.item as ItemId;
      const definition = items[id];
      if (['weapon', 'armor', 'head', 'accessory'].includes(definition?.type)) socket?.emit('equip', id);
      else if (id === 'town_scroll') socket?.emit('use:item', id);
      else if (id === 'red_potion') socket?.emit('potion');
    };
  });
}

function renderSkills() {
  if (!me) return;
  $('#skill-points').textContent = `แต้มสกิลคงเหลือ: ${me.skillPoints}`;

  const definitions = [
    ['firstAid', 'First Aid', '❤️', 'ฟื้นฟูตัวเอง'],
    ['bash', 'Bash', '💥', 'โจมตีหนักระยะประชิด'],
    ['firebolt', 'Fire Bolt', '🔥', 'เวทไฟระยะไกล'],
    ['doubleShot', 'Double Shot', '🏹', 'ยิงลูกศรสองครั้ง'],
  ] as const;

  $('#skill-grid').innerHTML = definitions
    .map(
      ([key, name, icon, description]) => `
        <button class="item skill" data-skill="${key}">
          <strong>${icon}</strong>
          <span>${name}</span>
          <small>${description}</small>
          <em>Lv.${me!.skills[key]}/5</em>
        </button>`,
    )
    .join('');

  document.querySelectorAll<HTMLButtonElement>('[data-skill]').forEach((button) => {
    button.onclick = () => socket?.emit('skill:up', button.dataset.skill);
  });
}

function renderShop(list: ItemDef[]) {
  $('#shop-grid').innerHTML = list
    .map(
      (item) => `
        <button class="item shop-item" data-buy="${item.id}">
          <strong>${item.icon}</strong>
          <span>${item.name}</span>
          <small>${item.atk ? `ATK +${item.atk} · ` : ''}${item.matk ? `MATK +${item.matk} · ` : ''}${item.def ? `DEF +${item.def} · ` : ''}${item.price} Zeny</small>
        </button>`,
    )
    .join('');

  document.querySelectorAll<HTMLButtonElement>('[data-buy]').forEach((button) => {
    button.onclick = () => socket?.emit('buy', button.dataset.buy);
  });
  openModal('shop');
}

function renderParty(party: PartyState | null) {
  $('#party-members').innerHTML = party
    ? party.members
        .map((member) => `<div>${member.id === party.leaderId ? '👑' : '•'} ${member.name} <small>${member.job} Lv.${member.level}</small></div>`)
        .join('')
    : '<span class="muted">ยังไม่มีปาร์ตี้</span>';
}

function openModal(id: string) {
  $('#' + id).classList.remove('hidden');
}

function closeModal(id: string) {
  $('#' + id).classList.add('hidden');
}

function toggleModal(id: string) {
  $('#' + id).classList.toggle('hidden');
}

$('#login-btn').onclick = () => auth('login');
$('#register-btn').onclick = () => auth('register');
$('#new-char-btn').onclick = createCharacter;

qs<HTMLInputElement>('#password').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') auth('login');
});

addEventListener(
  'hok-state',
  ((event: CustomEvent<PlayerNet>) => {
    me = { ...((me || {}) as PlayerNet), ...event.detail };
    renderAll();
  }) as EventListener,
);

addEventListener(
  'hok-map',
  ((event: CustomEvent<string>) => {
    $('#map').textContent = event.detail === 'town' ? 'HOKADIW Town' : 'Poring Field';
  }) as EventListener,
);

qs<HTMLFormElement>('#chat-form').onsubmit = (event) => {
  event.preventDefault();
  const input = qs<HTMLInputElement>('#chat-input');
  const text = input.value.trim();
  if (text && socket) {
    socket.emit('chat', text);
    input.value = '';
  }
};

document.querySelectorAll<HTMLButtonElement>('[data-act]').forEach((button) => {
  button.onclick = () => dispatchEvent(new CustomEvent('hok-act', { detail: button.dataset.act }));
});

document.querySelectorAll<HTMLButtonElement>('[data-dir]').forEach((button) => {
  const direction = button.dataset.dir!;
  const on = (event: PointerEvent) => {
    event.preventDefault();
    button.setPointerCapture?.(event.pointerId);
    dispatchEvent(new CustomEvent('hok-dir', { detail: `on:${direction}` }));
  };
  const off = (event: PointerEvent) => {
    event.preventDefault();
    dispatchEvent(new CustomEvent('hok-dir', { detail: `off:${direction}` }));
  };
  button.addEventListener('pointerdown', on);
  button.addEventListener('pointerup', off);
  button.addEventListener('pointercancel', off);
  button.addEventListener('pointerleave', off);
});

$('#inventory-btn').onclick = () => toggleModal('inventory');
$('#skill-btn').onclick = () => toggleModal('skills');
$('#shop-btn').onclick = () => socket?.emit('shop');
$('#trade-btn').onclick = () => {
  if (!me?.inventory?.length) return toast('ยังไม่มีไอเทมสำหรับ Trade');
  const target = prompt('ชื่อตัวละครปลายทาง');
  if (!target) return;
  const itemId = prompt('Item ID (เว้นว่างถ้าส่งเฉพาะ Zeny)') as ItemId | null;
  const qty = itemId ? Number(prompt('จำนวน') || 1) : 0;
  const zeny = Number(prompt('Zeny ที่จะส่ง') || 0);
  socket?.emit('trade:offer', { target, itemId: itemId || undefined, qty, zeny });
};

addEventListener('hok-open-inventory', () => toggleModal('inventory'));
addEventListener('hok-open-skills', () => toggleModal('skills'));
addEventListener('hok-open-shop', () => socket?.emit('shop'));

document.querySelectorAll<HTMLButtonElement>('[data-close]').forEach((button) => {
  button.onclick = () => closeModal(button.dataset.close!);
});

document.querySelectorAll<HTMLElement>('.modal').forEach((modal) => {
  modal.addEventListener('pointerdown', (event) => {
    if (event.target === modal && modal.id !== 'characters') closeModal(modal.id);
  });
});

addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    ['inventory', 'skills', 'shop'].forEach(closeModal);
  }
});

$('#party-create').onclick = () => socket?.emit('party:create');
$('#party-invite').onclick = () => {
  const name = prompt('ชื่อตัวละครที่จะเชิญ');
  if (name) socket?.emit('party:invite', name);
};
$('#party-leave').onclick = () => socket?.emit('party:leave');
