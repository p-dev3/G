import Phaser from 'phaser';
import type { Socket } from 'socket.io-client';
import type { DropNet, Job, MonsterNet, PlayerNet } from './types';

const WORLD_W = 2400;
const WORLD_H = 1600;

export class WorldScene extends Phaser.Scene {
  socket!: Socket;
  selfId = '';
  map = 'town';
  me?: Phaser.Physics.Arcade.Sprite;

  private players = new Map<string, Phaser.Physics.Arcade.Sprite>();
  private monsters = new Map<string, Phaser.GameObjects.Sprite>();
  private drops = new Map<string, Phaser.GameObjects.Container>();
  private labels = new Map<string, Phaser.GameObjects.Text>();
  private scenery: Phaser.GameObjects.GameObject[] = [];

  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd!: Record<string, Phaser.Input.Keyboard.Key>;
  private mobile = new Set<string>();
  private lastSend = 0;

  constructor() {
    super('world');
  }

  init(data?: { socket?: Socket; selfId?: string }) {
    if (data?.socket) this.socket = data.socket;
    if (data?.selfId) this.selfId = data.selfId;
  }

  create() {
    if (!this.socket) throw new Error('WorldScene started without a socket');

    this.makeTextures();
    this.physics.world.setBounds(0, 0, WORLD_W, WORLD_H);
    this.cameras.main.setBackgroundColor('#1a2419');
    this.drawMap('town');

    this.cursors = this.input.keyboard!.createCursorKeys();
    this.wasd = this.input.keyboard!.addKeys('W,A,S,D') as Record<string, Phaser.Input.Keyboard.Key>;

    this.input.keyboard!.on('keydown-SPACE', () => this.socket.emit('attack'));
    this.input.keyboard!.on('keydown-ONE', () => this.socket.emit('skill'));
    this.input.keyboard!.on('keydown-Q', () => this.socket.emit('potion'));
    this.input.keyboard!.on('keydown-E', () => dispatchEvent(new CustomEvent('hok-open-shop')));
    this.input.keyboard!.on('keydown-I', () => dispatchEvent(new CustomEvent('hok-open-inventory')));
    this.input.keyboard!.on('keydown-K', () => dispatchEvent(new CustomEvent('hok-open-skills')));

    addEventListener(
      'hok-dir',
      ((event: CustomEvent<string>) => {
        const [mode, direction] = event.detail.split(':');
        mode === 'on' ? this.mobile.add(direction) : this.mobile.delete(direction);
      }) as EventListener,
    );

    addEventListener(
      'hok-act',
      ((event: CustomEvent<string>) => this.socket.emit(event.detail)) as EventListener,
    );

    this.socket.on('snapshot', (snapshot: any) => this.snapshot(snapshot));
    this.socket.on('map:changed', (data: any) => {
      this.map = data.map;
      this.clearWorld();
      this.drawMap(this.map);
      this.snapshot(data.snapshot);
      dispatchEvent(new CustomEvent('hok-map', { detail: this.map }));
    });
    this.socket.on('state', (player: PlayerNet) => {
      if (player.map === this.map) this.upsertPlayer(player);
    });
    this.socket.on('self', (player: PlayerNet) => dispatchEvent(new CustomEvent('hok-state', { detail: player })));
    this.socket.on('player:left', (id: string) => this.removePlayer(id));
    this.socket.on('monster', (monster: MonsterNet) => {
      if (monster.map === this.map) this.upsertMonster(monster);
    });
    this.socket.on('drop', (drop: DropNet) => {
      if (drop.map === this.map) this.upsertDrop(drop);
    });
    this.socket.on('drop:remove', (id: string) => this.removeDrop(id));
    this.socket.on('fx:damage', (data: { x: number; y: number; amount: number }) => {
      this.float(data.x, data.y, `-${data.amount}`, '#ffe3a0');
    });
    this.socket.on('fx:playerDamage', (data: { amount: number }) => {
      if (!this.me) return;
      this.cameras.main.shake(90, 0.0025);
      this.float(this.me.x, this.me.y, `-${data.amount}`, '#ff9e9e');
    });

    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      const worldPoint = pointer.positionToCamera(this.cameras.main) as Phaser.Math.Vector2;
      let nearest: string | undefined;
      let distance = 70;

      for (const [id, container] of this.drops) {
        const current = Phaser.Math.Distance.Between(worldPoint.x, worldPoint.y, container.x, container.y);
        if (current < distance) {
          distance = current;
          nearest = id;
        }
      }
      if (nearest) this.socket.emit('pickup', nearest);
    });
  }

  update(time: number) {
    if (!this.me) return;

    let x = 0;
    let y = 0;
    if (this.cursors.left.isDown || this.wasd.A.isDown || this.mobile.has('left')) x--;
    if (this.cursors.right.isDown || this.wasd.D.isDown || this.mobile.has('right')) x++;
    if (this.cursors.up.isDown || this.wasd.W.isDown || this.mobile.has('up')) y--;
    if (this.cursors.down.isDown || this.wasd.S.isDown || this.mobile.has('down')) y++;

    const vector = new Phaser.Math.Vector2(x, y);
    if (vector.lengthSq()) {
      vector.normalize();
      if (time - this.lastSend > 38) {
        this.lastSend = time;
        this.socket.emit('move', { dx: vector.x, dy: vector.y });
      }
    }

    for (const [id, label] of this.labels) {
      const sprite = this.players.get(id);
      if (sprite) label.setPosition(sprite.x, sprite.y - 44);
    }
  }

  private snapshot(snapshot: { players: PlayerNet[]; monsters: MonsterNet[]; drops: DropNet[] }) {
    for (const player of snapshot.players) this.upsertPlayer(player);
    for (const monster of snapshot.monsters) this.upsertMonster(monster);
    for (const drop of snapshot.drops || []) this.upsertDrop(drop);
  }

  private clearWorld() {
    for (const sprite of this.players.values()) sprite.destroy();
    for (const label of this.labels.values()) label.destroy();
    for (const monster of this.monsters.values()) monster.destroy();
    for (const drop of this.drops.values()) drop.destroy();

    this.players.clear();
    this.labels.clear();
    this.monsters.clear();
    this.drops.clear();
    this.me = undefined;
  }

  private clearScenery() {
    for (const object of this.scenery) object.destroy();
    this.scenery = [];
  }

  private keep<T extends Phaser.GameObjects.GameObject>(...objects: T[]) {
    this.scenery.push(...objects);
    return objects;
  }

  private playerTexture(job: Job) {
    return `hero-${job.toLowerCase()}`;
  }

  private upsertPlayer(player: PlayerNet) {
    let sprite = this.players.get(player.id);

    if (!sprite) {
      sprite = this.physics.add.sprite(player.x, player.y, this.playerTexture(player.job)).setDepth(8);
      sprite.setOrigin(0.5, 0.72);
      this.players.set(player.id, sprite);

      const isSelf = player.id === this.selfId;
      const label = this.add
        .text(player.x, player.y - 44, `${isSelf ? '◆ ' : ''}${player.name}`, {
          fontFamily: 'system-ui, sans-serif',
          fontSize: '12px',
          fontStyle: isSelf ? 'bold' : 'normal',
          color: isSelf ? '#ffe7a3' : '#ffffff',
          stroke: '#17120d',
          strokeThickness: 4,
        })
        .setOrigin(0.5)
        .setDepth(12);
      this.labels.set(player.id, label);

      if (isSelf) {
        this.me = sprite;
        sprite.setScale(1.08);
        this.cameras.main
          .setBounds(0, 0, WORLD_W, WORLD_H)
          .startFollow(sprite, true, 0.1, 0.1)
          .setZoom(1.15)
          .setRoundPixels(true);
      }
    }

    if (sprite.texture.key !== this.playerTexture(player.job)) sprite.setTexture(this.playerTexture(player.job));
    sprite.setAlpha(player.dead ? 0.45 : 1);

    this.tweens.killTweensOf(sprite);
    this.tweens.add({
      targets: sprite,
      x: player.x,
      y: player.y,
      duration: 72,
      ease: 'Linear',
    });
  }

  private removePlayer(id: string) {
    this.players.get(id)?.destroy();
    this.players.delete(id);
    this.labels.get(id)?.destroy();
    this.labels.delete(id);
  }

  private upsertMonster(monster: MonsterNet) {
    let sprite = this.monsters.get(monster.id);
    if (!sprite) {
      sprite = this.add.sprite(monster.x, monster.y, 'slime').setDepth(6).setOrigin(0.5, 0.72);
      this.monsters.set(monster.id, sprite);
      this.tweens.add({
        targets: sprite,
        scaleY: 0.94,
        scaleX: 1.05,
        duration: 620,
        yoyo: true,
        repeat: -1,
        ease: 'Sine.inOut',
      });
    }

    sprite.setVisible(monster.alive).setAlpha(monster.alive ? 1 : 0);
    if (monster.alive) {
      this.tweens.add({ targets: sprite, x: monster.x, y: monster.y, duration: 90, ease: 'Linear' });
    }
  }

  private upsertDrop(drop: DropNet) {
    if (this.drops.has(drop.id)) return;

    const iconMap: Partial<Record<DropNet['itemId'], string>> = {
      poring_gel: '💧',
      red_potion: '🧪',
      town_scroll: '📜',
      sword: '⚔️',
      staff: '🪄',
      bow: '🏹',
      cap: '🎩',
      ring: '💍',
    };

    const glow = this.add.circle(0, 8, 19, 0xffd978, 0.2);
    const ring = this.add.circle(0, 8, 13).setStrokeStyle(1, 0xffe9a8, 0.45);
    const icon = this.add.text(0, 0, iconMap[drop.itemId] || '✦', { fontSize: '21px' }).setOrigin(0.5);
    const container = this.add
      .container(drop.x, drop.y, [glow, ring, icon])
      .setDepth(7)
      .setInteractive(new Phaser.Geom.Circle(0, 0, 30), Phaser.Geom.Circle.Contains);

    this.tweens.add({ targets: container, y: drop.y - 7, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    this.tweens.add({ targets: glow, alpha: 0.08, scale: 1.35, duration: 900, yoyo: true, repeat: -1 });
    this.drops.set(drop.id, container);
  }

  private removeDrop(id: string) {
    this.drops.get(id)?.destroy();
    this.drops.delete(id);
  }

  private float(x: number, y: number, text: string, color: string) {
    const label = this.add
      .text(x, y - 34, text, {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '15px',
        fontStyle: 'bold',
        color,
        stroke: '#321c18',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(30);

    this.tweens.add({
      targets: label,
      y: y - 74,
      alpha: 0,
      scale: 1.12,
      duration: 720,
      ease: 'Cubic.out',
      onComplete: () => label.destroy(),
    });
  }

  private drawMap(map: string) {
    this.clearScenery();

    if (map === 'town') this.drawTown();
    else this.drawField();
  }

  private drawTown() {
    const ground = this.add.tileSprite(WORLD_W / 2, WORLD_H / 2, WORLD_W, WORLD_H, 'grass-town').setDepth(-20);
    const verticalRoad = this.add.tileSprite(1120, WORLD_H / 2, 300, WORLD_H, 'stone-road').setDepth(-15);
    const horizontalRoad = this.add.tileSprite(WORLD_W / 2, 770, WORLD_W, 230, 'stone-road').setDepth(-15);
    const plaza = this.add.ellipse(1120, 770, 560, 390, 0xc8b98b, 0.22).setDepth(-14);
    this.keep(ground, verticalRoad, horizontalRoad, plaza);

    const shade = this.add.graphics().setDepth(-12);
    shade.fillStyle(0x344f31, 0.18);
    shade.fillCircle(360, 420, 280);
    shade.fillCircle(2050, 1260, 330);
    shade.fillCircle(2080, 270, 250);
    this.keep(shade);

    [
      [300, 310, 1.05],
      [520, 1180, 0.95],
      [1820, 330, 1.0],
      [1940, 1160, 1.08],
    ].forEach(([x, y, scale]) => this.addHouse(x, y, scale));

    [
      [120, 160], [690, 160], [1550, 130], [2180, 180], [220, 1420], [760, 1450], [1560, 1430], [2260, 1410],
      [110, 980], [2260, 900], [360, 600], [1890, 650],
    ].forEach(([x, y], index) => this.addTree(x, y, index % 3 === 0 ? 1.12 : 0.94));

    [
      [790, 530], [1435, 525], [785, 1010], [1445, 1010], [995, 580], [1250, 580],
    ].forEach(([x, y]) => this.addFlowerPatch(x, y));

    [
      [915, 520], [1325, 520], [915, 1020], [1325, 1020],
    ].forEach(([x, y]) => this.addLamp(x, y));

    this.addFenceLine(720, 365, 6, 'horizontal');
    this.addFenceLine(1530, 370, 6, 'horizontal');
    this.addFenceLine(720, 1180, 6, 'horizontal');
    this.addFenceLine(1530, 1180, 6, 'horizontal');

    const board = this.add.image(870, 705, 'notice-board').setDepth(3);
    const boardLabel = this.add
      .text(870, 632, 'QUEST BOARD', {
        fontFamily: 'Georgia, serif',
        fontSize: '12px',
        fontStyle: 'bold',
        color: '#ffe4a6',
        stroke: '#2d2116',
        strokeThickness: 3,
      })
      .setOrigin(0.5)
      .setDepth(4);
    this.keep(board, boardLabel);

    const npc = this.add.image(1280, 720, 'npc').setDepth(7).setOrigin(0.5, 0.75);
    const npcShadow = this.add.ellipse(1280, 746, 42, 15, 0x102010, 0.28).setDepth(5);
    const npcLabel = this.add
      .text(1280, 665, 'Mira · Shop [E]', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '13px',
        fontStyle: 'bold',
        color: '#ffe8a6',
        stroke: '#2a2018',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(11);
    this.keep(npcShadow, npc, npcLabel);

    const portal = this.add.image(2315, 770, 'portal').setDepth(2);
    const portalLabel = this.add
      .text(2240, 665, 'PORING FIELD  →', {
        fontFamily: 'Georgia, serif',
        fontSize: '17px',
        fontStyle: 'bold',
        color: '#e9f7ff',
        stroke: '#263438',
        strokeThickness: 5,
      })
      .setOrigin(0.5)
      .setDepth(10);
    this.tweens.add({ targets: portal, alpha: 0.62, scaleX: 1.1, duration: 1000, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    this.keep(portal, portalLabel);

    const title = this.add
      .text(1120, 390, 'HOKADIW TOWN', {
        fontFamily: 'Georgia, serif',
        fontSize: '34px',
        fontStyle: 'bold',
        color: '#fff1bf',
        stroke: '#36442f',
        strokeThickness: 8,
      })
      .setOrigin(0.5)
      .setDepth(1)
      .setAlpha(0.82);
    const subtitle = this.add
      .text(1120, 432, 'Heart of the Realms', {
        fontFamily: 'Georgia, serif',
        fontSize: '14px',
        color: '#f5e7c0',
        stroke: '#36442f',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(1)
      .setAlpha(0.72);
    this.keep(title, subtitle);
  }

  private drawField() {
    const ground = this.add.tileSprite(WORLD_W / 2, WORLD_H / 2, WORLD_W, WORLD_H, 'grass-field').setDepth(-20);
    this.keep(ground);

    const trails = this.add.graphics().setDepth(-15);
    trails.fillStyle(0xb9ab79, 0.28);
    trails.fillRoundedRect(0, 680, 620, 210, 80);
    trails.fillRoundedRect(420, 735, 1280, 120, 55);
    trails.fillRoundedRect(1500, 560, 880, 170, 70);
    trails.fillStyle(0x446a3d, 0.18);
    trails.fillCircle(900, 630, 350);
    trails.fillCircle(1650, 980, 430);
    trails.fillCircle(2000, 420, 250);
    this.keep(trails);

    [
      [220, 220], [480, 130], [830, 210], [1210, 150], [1580, 170], [2050, 180], [2260, 320],
      [150, 1270], [460, 1450], [920, 1390], [1500, 1430], [1960, 1370], [2280, 1230],
      [780, 1040], [1730, 1040],
    ].forEach(([x, y], index) => this.addTree(x, y, index % 4 === 0 ? 1.15 : 0.9));

    [
      [350, 520], [670, 500], [1010, 1080], [1320, 1140], [1820, 610], [2080, 920], [440, 1130], [1470, 450],
    ].forEach(([x, y]) => this.addFlowerPatch(x, y));

    [
      [560, 960], [920, 440], [1440, 920], [1900, 1180], [2160, 560],
    ].forEach(([x, y], index) => {
      const rock = this.add.image(x, y, 'rock').setDepth(2).setScale(index % 2 ? 0.8 : 1.05);
      this.keep(rock);
    });

    const portal = this.add.image(72, 780, 'portal').setDepth(2).setFlipX(true);
    const label = this.add
      .text(120, 650, '←  HOKADIW TOWN', {
        fontFamily: 'Georgia, serif',
        fontSize: '17px',
        fontStyle: 'bold',
        color: '#edf8ff',
        stroke: '#263438',
        strokeThickness: 5,
      })
      .setDepth(10);
    this.tweens.add({ targets: portal, alpha: 0.62, scaleX: 1.1, duration: 1000, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    this.keep(portal, label);

    const title = this.add
      .text(1200, 105, 'PORING FIELD', {
        fontFamily: 'Georgia, serif',
        fontSize: '34px',
        fontStyle: 'bold',
        color: '#fff0bd',
        stroke: '#31502d',
        strokeThickness: 8,
      })
      .setOrigin(0.5)
      .setDepth(1)
      .setAlpha(0.78);
    const subtitle = this.add
      .text(1200, 145, 'The Green Frontier', {
        fontFamily: 'Georgia, serif',
        fontSize: '14px',
        color: '#f1edc9',
        stroke: '#31502d',
        strokeThickness: 4,
      })
      .setOrigin(0.5)
      .setDepth(1)
      .setAlpha(0.72);
    this.keep(title, subtitle);
  }

  private addHouse(x: number, y: number, scale = 1) {
    const shadow = this.add.ellipse(x, y + 62 * scale, 210 * scale, 70 * scale, 0x172116, 0.28).setDepth(0);
    const house = this.add.image(x, y, 'house').setDepth(2).setScale(scale).setOrigin(0.5, 0.72);
    this.keep(shadow, house);
  }

  private addTree(x: number, y: number, scale = 1) {
    const shadow = this.add.ellipse(x + 8, y + 36 * scale, 90 * scale, 35 * scale, 0x132013, 0.24).setDepth(0);
    const tree = this.add.image(x, y, 'tree').setDepth(3).setScale(scale).setOrigin(0.5, 0.82);
    this.keep(shadow, tree);
  }

  private addFlowerPatch(x: number, y: number) {
    const flower = this.add.image(x, y, 'flowers').setDepth(1).setRotation(Phaser.Math.FloatBetween(-0.25, 0.25));
    this.keep(flower);
  }

  private addLamp(x: number, y: number) {
    const glow = this.add.circle(x, y - 32, 42, 0xffd974, 0.08).setDepth(2);
    const lamp = this.add.image(x, y, 'lamp').setDepth(4).setOrigin(0.5, 0.9);
    this.tweens.add({ targets: glow, alpha: 0.15, scale: 1.1, duration: 1300, yoyo: true, repeat: -1 });
    this.keep(glow, lamp);
  }

  private addFenceLine(x: number, y: number, count: number, direction: 'horizontal' | 'vertical') {
    for (let i = 0; i < count; i++) {
      const fence = this.add
        .image(x + (direction === 'horizontal' ? i * 56 : 0), y + (direction === 'vertical' ? i * 36 : 0), 'fence')
        .setDepth(2)
        .setRotation(direction === 'vertical' ? Math.PI / 2 : 0);
      this.keep(fence);
    }
  }

  private makeTextures() {
    if (this.textures.exists('hero-novice')) return;
    const g = this.make.graphics({ x: 0, y: 0, add: false });

    const tile = (key: string, base: number, fleck: number) => {
      g.clear();
      g.fillStyle(base).fillRect(0, 0, 64, 64);
      g.fillStyle(fleck, 0.34);
      const dots = [
        [8, 12, 2], [28, 6, 1], [49, 18, 2], [17, 41, 1], [40, 36, 2], [57, 53, 1], [5, 58, 1],
      ];
      dots.forEach(([x, y, r]) => g.fillCircle(x, y, r));
      g.lineStyle(1, 0x2c4628, 0.12).lineBetween(2, 28, 11, 24).lineBetween(45, 56, 52, 48);
      g.generateTexture(key, 64, 64);
    };
    tile('grass-town', 0x6e9a62, 0xb9d47e);
    tile('grass-field', 0x6b9f5e, 0xc4dc82);

    g.clear();
    g.fillStyle(0xb7a77d).fillRect(0, 0, 64, 64);
    g.lineStyle(2, 0x8f835f, 0.42);
    g.strokeRoundedRect(2, 4, 27, 20, 5).strokeRoundedRect(34, 1, 28, 25, 5).strokeRoundedRect(8, 31, 35, 28, 6).strokeRoundedRect(47, 32, 16, 25, 4);
    g.lineStyle(1, 0xe7d6a5, 0.28).lineBetween(6, 10, 24, 8).lineBetween(13, 39, 34, 36).lineBetween(39, 7, 57, 5);
    g.generateTexture('stone-road', 64, 64);

    const drawHero = (key: string, body: number, accent: number, job: Job) => {
      g.clear();
      g.fillStyle(0x223021, 0.24).fillEllipse(28, 57, 37, 12);
      g.fillStyle(0x3a2c23).fillRect(19, 44, 8, 12).fillRect(31, 44, 8, 12);
      g.fillStyle(body).fillRoundedRect(13, 26, 30, 24, 8);
      g.fillStyle(accent).fillRect(14, 39, 28, 6);
      g.fillStyle(0xf1cfb2).fillCircle(28, 21, 12);
      g.fillStyle(0x5b3a2d).fillCircle(28, 14, 12).fillTriangle(16, 18, 22, 5, 26, 14).fillTriangle(30, 12, 36, 4, 40, 19);
      g.fillStyle(0x2b2523).fillCircle(24, 21, 1.5).fillCircle(32, 21, 1.5);
      g.fillStyle(0xffffff, 0.45).fillCircle(23.5, 20.5, 0.55).fillCircle(31.5, 20.5, 0.55);

      if (job === 'Swordsman') {
        g.lineStyle(4, 0xd9dde2).lineBetween(43, 27, 51, 47);
        g.lineStyle(2, 0x8f6935).lineBetween(39, 32, 47, 29);
      } else if (job === 'Mage') {
        g.fillStyle(0x46518d).fillTriangle(15, 13, 28, 0, 42, 14).fillRect(11, 12, 34, 5);
        g.fillStyle(0xffd46d).fillCircle(28, 8, 2);
      } else if (job === 'Archer') {
        g.lineStyle(3, 0x70452f).strokeCircle(45, 33, 11);
        g.lineStyle(1, 0xe8d8b1).lineBetween(45, 22, 45, 44);
      } else {
        g.fillStyle(0xe6c45f).fillCircle(10, 34, 3);
      }
      g.generateTexture(key, 56, 64);
    };

    drawHero('hero-novice', 0x5e7085, 0xd7b85d, 'Novice');
    drawHero('hero-swordsman', 0x8a4d45, 0xd9c47a, 'Swordsman');
    drawHero('hero-mage', 0x4d568d, 0xb488e8, 'Mage');
    drawHero('hero-archer', 0x56764e, 0xd1b16f, 'Archer');

    g.clear();
    g.fillStyle(0x263525, 0.24).fillEllipse(25, 45, 40, 12);
    g.fillStyle(0xe99ac6).fillCircle(24, 25, 20);
    g.fillStyle(0xf8c8df).fillEllipse(24, 34, 31, 15);
    g.fillStyle(0xffffff, 0.42).fillCircle(17, 17, 6);
    g.fillStyle(0x2c2930).fillCircle(17, 24, 2.2).fillCircle(30, 24, 2.2);
    g.lineStyle(2, 0x894a6d).arc(24, 30, 6, 0.2, Math.PI - 0.2, false);
    g.generateTexture('slime', 50, 52);

    g.clear();
    g.fillStyle(0x243023, 0.24).fillEllipse(27, 58, 38, 11);
    g.fillStyle(0x6b4c34).fillRoundedRect(13, 29, 28, 26, 6);
    g.fillStyle(0xd6ad4d).fillRect(12, 43, 30, 5);
    g.fillStyle(0xf0ceb3).fillCircle(27, 21, 11);
    g.fillStyle(0xc49a69).fillCircle(27, 13, 11);
    g.fillStyle(0xeff2d0).fillRect(20, 20, 14, 3);
    g.generateTexture('npc', 54, 64);

    g.clear();
    g.fillStyle(0x142016, 0.22).fillEllipse(48, 108, 82, 25);
    g.fillStyle(0x715238).fillRoundedRect(39, 54, 18, 55, 7);
    g.fillStyle(0x315b31).fillCircle(48, 44, 34);
    g.fillStyle(0x3f7138).fillCircle(26, 49, 26).fillCircle(70, 50, 27).fillCircle(49, 24, 28);
    g.fillStyle(0x74a84e, 0.78).fillCircle(35, 28, 16).fillCircle(64, 34, 15);
    g.fillStyle(0xc9df74, 0.35).fillCircle(26, 38, 7).fillCircle(52, 17, 6);
    g.generateTexture('tree', 96, 120);

    g.clear();
    g.fillStyle(0x2a261f, 0.2).fillEllipse(120, 177, 215, 33);
    g.fillStyle(0xc6b58a).fillRoundedRect(20, 69, 200, 105, 10);
    g.fillStyle(0x9a6240).fillTriangle(4, 76, 120, 8, 236, 76);
    g.fillStyle(0x653b2d).fillTriangle(18, 70, 120, 18, 222, 70);
    g.fillStyle(0x6e4a32).fillRect(99, 119, 42, 55);
    g.fillStyle(0x3d6671).fillRect(48, 104, 35, 34).fillRect(157, 104, 35, 34);
    g.lineStyle(4, 0xd7c69c).strokeRect(48, 104, 35, 34).strokeRect(157, 104, 35, 34);
    g.fillStyle(0xe8c36c).fillCircle(132, 147, 3);
    g.generateTexture('house', 240, 190);

    g.clear();
    g.fillStyle(0x6c4a30).fillRect(4, 13, 58, 7).fillRect(8, 35, 54, 7).fillRect(12, 5, 7, 44).fillRect(48, 5, 7, 44);
    g.fillStyle(0x9a724a, 0.55).fillRect(6, 14, 54, 2).fillRect(10, 36, 50, 2);
    g.generateTexture('fence', 66, 52);

    g.clear();
    g.fillStyle(0x3e2f22).fillRect(20, 10, 8, 55);
    g.fillStyle(0x30271f).fillRect(10, 8, 28, 5);
    g.fillStyle(0xd99d38).fillRoundedRect(12, 12, 24, 22, 4);
    g.fillStyle(0xffe7a0, 0.75).fillRoundedRect(16, 15, 16, 15, 3);
    g.generateTexture('lamp', 48, 68);

    g.clear();
    g.fillStyle(0x294e25, 0.2).fillEllipse(40, 34, 78, 20);
    const flowers = [
      [8, 19, 0xffd45e], [18, 12, 0xf4a5cf], [30, 22, 0xd8f0ff], [43, 10, 0xfff09c], [55, 20, 0xe99ac6], [68, 13, 0xd9d6ff],
    ];
    flowers.forEach(([x, y, color]) => {
      g.fillStyle(0x4d7c3d).fillRect(x, y + 4, 2, 12);
      g.fillStyle(color).fillCircle(x, y, 4).fillCircle(x + 4, y + 2, 3).fillCircle(x - 3, y + 2, 3);
    });
    g.generateTexture('flowers', 80, 44);

    g.clear();
    g.fillStyle(0x5c5144).fillEllipse(32, 31, 58, 34);
    g.fillStyle(0x827565).fillEllipse(30, 23, 49, 27);
    g.fillStyle(0xb6aa95, 0.4).fillEllipse(22, 18, 19, 8);
    g.generateTexture('rock', 64, 48);

    g.clear();
    g.fillStyle(0x5e422b).fillRect(14, 26, 62, 46).fillRect(22, 8, 7, 70).fillRect(61, 8, 7, 70);
    g.fillStyle(0xb38b55).fillRect(20, 32, 50, 33);
    g.fillStyle(0xe1c487).fillRect(25, 37, 16, 9).fillRect(46, 37, 18, 9).fillRect(25, 51, 39, 8);
    g.generateTexture('notice-board', 90, 82);

    g.clear();
    g.fillStyle(0x63c8ff, 0.12).fillEllipse(44, 51, 74, 90);
    g.lineStyle(5, 0x9edfff, 0.75).strokeEllipse(44, 51, 66, 84);
    g.lineStyle(2, 0xe8fbff, 0.7).strokeEllipse(44, 51, 48, 65);
    g.fillStyle(0xbcecff, 0.28).fillEllipse(44, 51, 42, 59);
    g.fillStyle(0xffffff, 0.72).fillCircle(34, 27, 4).fillCircle(55, 64, 3);
    g.generateTexture('portal', 88, 102);

    g.destroy();
  }
}
