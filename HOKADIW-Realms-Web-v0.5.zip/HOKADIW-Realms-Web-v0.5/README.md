# HOKADIW Realms Web v0.5

Browser MMORPG prototype built with **Phaser 3 + TypeScript** and an authoritative **Node.js / Socket.IO** server.

## v0.5 highlights

### Gameplay
- Account login and up to 3 character slots
- Jobs: Novice, Swordsman, Mage, Archer
- Skill points and skill tree: First Aid, Bash, Fire Bolt, Double Shot
- Job-sensitive active skill on hotkey `1`
- Server-side monster chase/attack AI
- Player death and timed respawn in HOKADIW Town
- Party EXP sharing for nearby members
- Player-to-player trade offers for items and Zeny
- Equipment slots: weapon, armor, head, accessory
- Expanded loot and Mira shop
- Existing v0.4 systems retained: maps/portals, chat, party, drops, inventory, authoritative movement/combat

### UI / graphics overhaul
- Fantasy RPG HUD with compact HP / MP / EXP meters
- Job portrait and job-specific player sprites
- New login and character-selection presentation
- Optimized cinematic login artwork (`client/public/assets/login-world.webp`)
- Reworked HOKADIW Town with roads, plaza, houses, trees, fences, flowers, lamps, quest board and animated portal
- Reworked Poring Field with trails, foliage, rocks, flowers and animated portal
- Improved slime, NPC, loot glow and damage feedback
- Fixed scenery cleanup when changing maps so old map layers do not accumulate
- Responsive mobile HUD + touch D-pad
- Reduced-motion support for accessibility

## Run locally

```bash
npm install
npm run dev
```

- Client: `http://localhost:5173`
- Server: `http://localhost:3001`
- Health: `http://localhost:3001/health`

To point the client at another server, copy `client/.env.example` and set `VITE_SERVER_URL`.

## Controls

| Control | Action |
|---|---|
| WASD / Arrow keys | Move |
| Space | Basic attack |
| 1 | Job skill |
| Q | Potion |
| I | Inventory |
| K | Skill tree |
| E | Mira shop |
| Touch D-pad | Mobile movement |

## Project structure

```text
client/
  public/assets/       Login artwork
  src/game/            Phaser world scene + network types
  src/main.ts          DOM HUD, auth, inventory, skills, party, trade
server/
  src/index.ts         Authoritative Socket.IO game server
  data/accounts.json   Development persistence (generated at runtime)
```

## Development note

Development persistence remains JSON in `server/data/accounts.json`. For a production deployment, move accounts/characters/items/trades to PostgreSQL and use Redis for ephemeral sessions and room presence.
