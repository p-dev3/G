export type ItemId='red_potion'|'knife'|'sword'|'cloth_armor'|'poring_gel'|'town_scroll';
export type ItemDef={id:ItemId,name:string,icon:string,type:'consumable'|'weapon'|'armor'|'material',price:number,atk?:number,def?:number};
export type InventoryRow={id:ItemId,qty:number,def:ItemDef};
export type PlayerNet={id:string,name:string,map:string,x:number,y:number,dir:number,hp:number,maxHp:number,mp:number,maxMp:number,level:number,exp:number,kills:number,zeny:number,atk:number,def:number,equipment:{weapon?:ItemId,armor?:ItemId},partyId?:string,inventory?:InventoryRow[]};
export type MonsterNet={id:string,map:string,x:number,y:number,hp:number,maxHp:number,alive:boolean};
export type DropNet={id:string,map:string,x:number,y:number,itemId:ItemId,qty:number,ownerId?:string,expiresAt:number};
