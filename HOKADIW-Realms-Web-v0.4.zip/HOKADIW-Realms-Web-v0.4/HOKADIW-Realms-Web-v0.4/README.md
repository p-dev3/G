# HOKADIW Realms Web v0.4

Browser MMORPG prototype built with Phaser 3 + TypeScript + Vite + Node.js + Socket.IO.

## v0.4 highlights
- Account registration/login with password hashes using Node `crypto.scrypt`
- Session token authentication for Socket.IO
- Server-owned character save state
- Inventory and equipment synchronized from the server
- Weapon ATK and armor DEF stats
- Monster drops: Poring Gel, Red Potion, Town Scroll
- Click/tap drops to pick them up
- Mira NPC shop with server-side price/distance validation
- Two synchronized maps: HOKADIW Town and Poring Field
- Portal transitions controlled by the server
- Party create/invite/accept/leave flow, up to 5 members
- Chat scoped to current map
- Server-authoritative movement/combat/item purchasing/equipping
- Desktop and mobile controls

## Run
```bash
npm install
npm run dev
```
Client: http://localhost:5173
Server: http://localhost:3001
Health: http://localhost:3001/health

## Controls
- WASD / arrows: move
- Space: attack
- 1: Whirl Slash
- Q: Red Potion
- I: inventory
- E: shop
- Click/tap item drops: pick up

## Test multiplayer
1. Register two separate accounts.
2. Open two browser tabs/windows.
3. Login with each account.
4. Walk east through the glowing portal to Poring Field.
5. Kill monsters, pick up drops, invite the other character to a party.

## Persistence
Development persistence is stored in `server/data/accounts.json` and passwords are salted+scrypt hashed. For production, move accounts/sessions/characters/items to PostgreSQL or another transactional database, serve behind HTTPS, add CSRF/rate limiting where relevant, and replace in-memory sessions with Redis or signed short-lived access tokens.
