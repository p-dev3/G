import express from 'express';
import cors from 'cors';
import {createServer} from 'http';
import {Server, Socket} from 'socket.io';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

type ItemId='red_potion'|'knife'|'sword'|'cloth_armor'|'poring_gel'|'town_scroll';
type ItemDef={id:ItemId,name:string,icon:string,type:'consumable'|'weapon'|'armor'|'material',price:number,atk?:number,def?:number};
type Stack={id:ItemId,qty:number};
type Equipment={weapon?:ItemId,armor?:ItemId};
type Account={username:string,passwordHash:string,salt:string,character:CharacterSave};
type CharacterSave={name:string,map:string,x:number,y:number,hp:number,maxHp:number,mp:number,maxMp:number,level:number,exp:number,kills:number,zeny:number,inventory:Stack[],equipment:Equipment};
type Player=CharacterSave & {id:string,username:string,dir:number,lastAttack:number,lastMove:number,lastSkill:number,partyId?:string};
type Monster={id:string,map:string,x:number,y:number,hp:number,maxHp:number,alive:boolean,respawnAt:number};
type Drop={id:string,map:string,x:number,y:number,itemId:ItemId,qty:number,ownerId?:string,expiresAt:number};
type Party={id:string,leaderId:string,members:Set<string>};

const ITEMS:Record<ItemId,ItemDef>={
 red_potion:{id:'red_potion',name:'Red Potion',icon:'🧪',type:'consumable',price:25},
 knife:{id:'knife',name:'Training Knife',icon:'🗡️',type:'weapon',price:80,atk:4},
 sword:{id:'sword',name:'Iron Sword',icon:'⚔️',type:'weapon',price:450,atk:12},
 cloth_armor:{id:'cloth_armor',name:'Cloth Armor',icon:'🥋',type:'armor',price:320,def:7},
 poring_gel:{id:'poring_gel',name:'Poring Gel',icon:'💧',type:'material',price:8},
 town_scroll:{id:'town_scroll',name:'Town Scroll',icon:'📜',type:'consumable',price:120}
};
const MAPS={town:{w:2400,h:1600,spawn:{x:1030,y:760}},field:{w:2400,h:1600,spawn:{x:280,y:780}}} as const;
const PORT=Number(process.env.PORT||3001);
const DATA_DIR=path.resolve('data'); const ACCOUNTS_PATH=path.join(DATA_DIR,'accounts.json'); fs.mkdirSync(DATA_DIR,{recursive:true});
const app=express(); app.use(cors()); app.use(express.json()); const http=createServer(app); const io=new Server(http,{cors:{origin:'*'}});
const players=new Map<string,Player>(),monsters=new Map<string,Monster>(),drops=new Map<string,Drop>(),parties=new Map<string,Party>();
let accounts:Record<string,Account>={}; try{accounts=JSON.parse(fs.readFileSync(ACCOUNTS_PATH,'utf8'))}catch{}
const sessions=new Map<string,string>();
const sanitize=(v:string,n=16)=>String(v||'').replace(/[^\p{L}\p{N}_ -]/gu,'').trim().slice(0,n);
const hashPassword=(password:string,salt:string)=>crypto.scryptSync(password,salt,32).toString('hex');
const newCharacter=(name:string):CharacterSave=>({name,map:'town',x:MAPS.town.spawn.x,y:MAPS.town.spawn.y,hp:100,maxHp:100,mp:40,maxMp:40,level:1,exp:0,kills:0,zeny:150,inventory:[{id:'red_potion',qty:5},{id:'knife',qty:1}],equipment:{weapon:'knife'}});
const persist=()=>fs.writeFileSync(ACCOUNTS_PATH,JSON.stringify(accounts,null,2));
const savePlayer=(p:Player)=>{const a=accounts[p.username];if(!a)return;a.character={name:p.name,map:p.map,x:p.x,y:p.y,hp:p.hp,maxHp:p.maxHp,mp:p.mp,maxMp:p.maxMp,level:p.level,exp:p.exp,kills:p.kills,zeny:p.zeny,inventory:p.inventory,equipment:p.equipment};};
const addItem=(p:Player,id:ItemId,qty=1)=>{const s=p.inventory.find(x=>x.id===id);s?s.qty+=qty:p.inventory.push({id,qty});};
const removeItem=(p:Player,id:ItemId,qty=1)=>{const s=p.inventory.find(x=>x.id===id);if(!s||s.qty<qty)return false;s.qty-=qty;if(s.qty<=0)p.inventory=p.inventory.filter(x=>x.qty>0);return true;};
const atkOf=(p:Player)=>10+p.level*4+(p.equipment.weapon?ITEMS[p.equipment.weapon].atk||0:0);
const defOf=(p:Player)=>(p.equipment.armor?ITEMS[p.equipment.armor].def||0:0);
const pub=(p:Player)=>({id:p.id,name:p.name,map:p.map,x:p.x,y:p.y,dir:p.dir,hp:p.hp,maxHp:p.maxHp,mp:p.mp,maxMp:p.maxMp,level:p.level,exp:p.exp,kills:p.kills,zeny:p.zeny,atk:atkOf(p),def:defOf(p),equipment:p.equipment,partyId:p.partyId});
const self=(p:Player)=>({...pub(p),inventory:p.inventory.map(x=>({...x,def:ITEMS[x.id]}))});
const emitSelf=(p:Player)=>io.to(p.id).emit('self',self(p));
const inMap=(map:string)=>[...players.values()].filter(p=>p.map===map).map(pub);
const mapSnapshot=(p:Player)=>({players:inMap(p.map),monsters:[...monsters.values()].filter(m=>m.map===p.map),drops:[...drops.values()].filter(d=>d.map===p.map)});
function spawnMonsters(){for(let i=0;i<24;i++){const map='field';monsters.set(`m${i}`,{id:`m${i}`,map,x:380+Math.random()*1850,y:100+Math.random()*1400,hp:58,maxHp:58,alive:true,respawnAt:0})}} spawnMonsters();
function createDrop(p:Player,m:Monster){const roll=Math.random();const itemId:ItemId=roll<.72?'poring_gel':roll<.9?'red_potion':'town_scroll';const d:Drop={id:crypto.randomUUID(),map:m.map,x:m.x+(Math.random()-.5)*25,y:m.y+(Math.random()-.5)*25,itemId,qty:1,ownerId:p.id,expiresAt:Date.now()+60000};drops.set(d.id,d);io.to(m.map).emit('drop',d)}
function enterMap(p:Player,map:keyof typeof MAPS,x?:number,y?:number){const old=p.map;p.map=map;p.x=x??MAPS[map].spawn.x;p.y=y??MAPS[map].spawn.y;p.id&&io.to(old).emit('player:left',p.id);const s=io.sockets.sockets.get(p.id);if(s){s.leave(old);s.join(map);s.emit('map:changed',{map,snapshot:mapSnapshot(p)});s.to(map).emit('state',pub(p))}emitSelf(p)}
function partyState(p:Player){if(!p.partyId)return null;const party=parties.get(p.partyId);if(!party)return null;return {id:party.id,leaderId:party.leaderId,members:[...party.members].map(id=>players.get(id)).filter(Boolean).map(x=>({id:x!.id,name:x!.name,level:x!.level,hp:x!.hp,maxHp:x!.maxHp}))}}
function emitParty(id?:string){if(!id)return;const party=parties.get(id);if(!party)return;for(const memberId of party.members){const p=players.get(memberId);if(p)io.to(memberId).emit('party',partyState(p))}}
app.get('/health',(_,r)=>r.json({ok:true,version:'0.4.0',online:players.size,accounts:Object.keys(accounts).length}));
app.get('/items',(_,r)=>r.json(ITEMS));
app.post('/api/register',(req,res)=>{const username=sanitize(req.body?.username,20).toLowerCase(),name=sanitize(req.body?.name,16),password=String(req.body?.password||'');if(username.length<3||password.length<6||!name)return res.status(400).json({error:'username>=3, password>=6 และต้องมีชื่อตัวละคร'});if(accounts[username])return res.status(409).json({error:'บัญชีนี้มีอยู่แล้ว'});const salt=crypto.randomBytes(16).toString('hex');accounts[username]={username,salt,passwordHash:hashPassword(password,salt),character:newCharacter(name)};persist();return res.json({ok:true})});
app.post('/api/login',(req,res)=>{const username=sanitize(req.body?.username,20).toLowerCase(),password=String(req.body?.password||''),a=accounts[username];if(!a||hashPassword(password,a.salt)!==a.passwordHash)return res.status(401).json({error:'ชื่อบัญชีหรือรหัสผ่านไม่ถูกต้อง'});const token=crypto.randomBytes(32).toString('hex');sessions.set(token,username);return res.json({token,character:{name:a.character.name,level:a.character.level}})});
setInterval(()=>{for(const p of players.values())savePlayer(p);persist()},15000);

io.on('connection',(s:Socket)=>{const token=String(s.handshake.auth.token||''),username=sessions.get(token);if(!username||!accounts[username]){s.emit('auth:error','session ไม่ถูกต้อง');return s.disconnect(true)}const c=accounts[username].character;const p:Player={...c,id:s.id,username,dir:0,lastAttack:0,lastMove:0,lastSkill:0};players.set(s.id,p);s.join(p.map);s.emit('snapshot',mapSnapshot(p));emitSelf(p);s.emit('items',ITEMS);s.emit('shop',{name:'Mira Shop',items:['red_potion','sword','cloth_armor','town_scroll'].map(id=>ITEMS[id as ItemId])});io.to(p.map).emit('state',pub(p));io.emit('online',players.size);io.to(p.map).emit('chat',{name:'SYSTEM',text:`${p.name} เข้าสู่ ${p.map==='town'?'HOKADIW Town':'Poring Field'}`});
 s.on('move',(v:{dx:number,dy:number})=>{const now=Date.now();if(now-p.lastMove<28)return;p.lastMove=now;let dx=Number(v?.dx)||0,dy=Number(v?.dy)||0;const len=Math.hypot(dx,dy);if(!len||len>1.5)return;dx/=len;dy/=len;const cfg=MAPS[p.map as keyof typeof MAPS];const speed=7;p.x=Math.max(20,Math.min(cfg.w-20,p.x+dx*speed));p.y=Math.max(20,Math.min(cfg.h-20,p.y+dy*speed));p.dir=Math.atan2(dy,dx);io.to(p.map).emit('state',pub(p));checkPortal(p)});
 s.on('attack',()=>attack(p,false));s.on('skill',()=>attack(p,true));
 s.on('potion',()=>{if(p.hp>=p.maxHp||!removeItem(p,'red_potion'))return;p.hp=Math.min(p.maxHp,p.hp+45);emitSelf(p)});
 s.on('pickup',(dropId:string)=>{const d=drops.get(String(dropId));if(!d||d.map!==p.map||Date.now()>d.expiresAt||Math.hypot(d.x-p.x,d.y-p.y)>90)return;addItem(p,d.itemId,d.qty);drops.delete(d.id);io.to(p.map).emit('drop:remove',d.id);emitSelf(p)});
 s.on('equip',(itemId:ItemId)=>{const def=ITEMS[itemId];if(!def||!p.inventory.some(x=>x.id===itemId))return;if(def.type==='weapon')p.equipment.weapon=itemId;else if(def.type==='armor')p.equipment.armor=itemId;else return;emitSelf(p);io.to(p.map).emit('state',pub(p))});
 s.on('buy',(itemId:ItemId)=>{const def=ITEMS[itemId];if(!def||!['red_potion','sword','cloth_armor','town_scroll'].includes(itemId)||p.map!=='town'||Math.hypot(p.x-1260,p.y-690)>260)return;if(p.zeny<def.price)return s.emit('toast','Zeny ไม่พอ');p.zeny-=def.price;addItem(p,itemId);emitSelf(p);s.emit('toast',`ซื้อ ${def.name} สำเร็จ`)});
 s.on('use:item',(itemId:ItemId)=>{if(itemId==='town_scroll'&&removeItem(p,itemId)){enterMap(p,'town');emitSelf(p)}});
 s.on('chat',(t:string)=>{const text=String(t||'').trim().slice(0,120);if(text)io.to(p.map).emit('chat',{name:p.name,text})});
 s.on('party:create',()=>{if(p.partyId)return;const id=crypto.randomUUID().slice(0,8);const party:Party={id,leaderId:p.id,members:new Set([p.id])};parties.set(id,party);p.partyId=id;emitParty(id)});
 s.on('party:invite',(targetName:string)=>{if(!p.partyId){const id=crypto.randomUUID().slice(0,8);parties.set(id,{id,leaderId:p.id,members:new Set([p.id])});p.partyId=id}const target=[...players.values()].find(x=>x.name.toLowerCase()===String(targetName).toLowerCase());if(!target||target.partyId)return s.emit('toast','ไม่พบผู้เล่นหรือผู้เล่นมีปาร์ตี้แล้ว');io.to(target.id).emit('party:invite',{partyId:p.partyId,from:p.name})});
 s.on('party:accept',(partyId:string)=>{const party=parties.get(String(partyId));if(!party||p.partyId||party.members.size>=5)return;party.members.add(p.id);p.partyId=party.id;emitParty(p.partyId)});
 s.on('party:leave',()=>leaveParty(p));
 s.on('disconnect',()=>{savePlayer(p);leaveParty(p);players.delete(s.id);io.to(p.map).emit('player:left',s.id);io.emit('online',players.size);persist()})
});
function leaveParty(p:Player){if(!p.partyId)return;const id=p.partyId,party=parties.get(id);p.partyId=undefined;if(!party)return;party.members.delete(p.id);if(party.leaderId===p.id)party.leaderId=[...party.members][0]||'';if(!party.members.size)parties.delete(id);else emitParty(id)}
function checkPortal(p:Player){if(p.map==='town'&&p.x>2280&&p.y>650&&p.y<930)enterMap(p,'field',300,790);else if(p.map==='field'&&p.x<90&&p.y>650&&p.y<930)enterMap(p,'town',2180,790)}
function attack(p:Player,aoe:boolean){const now=Date.now();if(aoe){if(now-p.lastSkill<800||p.mp<10)return;p.lastSkill=now;p.mp-=10}else{if(now-p.lastAttack<350)return;p.lastAttack=now}const range=aoe?130:88;let hit=false;for(const m of monsters.values()){if(!m.alive||m.map!==p.map)continue;if(Math.hypot(m.x-p.x,m.y-p.y)>range)continue;hit=true;const dmg=Math.max(1,atkOf(p)+(aoe?-3:3)+Math.floor(Math.random()*7));m.hp=Math.max(0,m.hp-dmg);io.to(p.map).emit('fx:damage',{x:m.x,y:m.y,amount:dmg});if(m.hp<=0){m.alive=false;m.respawnAt=now+6500;p.kills++;p.exp+=30;p.zeny+=5+Math.floor(Math.random()*8);createDrop(p,m);while(p.exp>=100+p.level*35){p.exp-=100+p.level*35;p.level++;p.maxHp+=18;p.maxMp+=6;p.hp=p.maxHp;p.mp=p.maxMp}}io.to(p.map).emit('monster',m);if(!aoe)break}if(hit||aoe){emitSelf(p);io.to(p.map).emit('state',pub(p));emitParty(p.partyId)}}
setInterval(()=>{const now=Date.now();for(const [id,d] of drops)if(now>d.expiresAt){drops.delete(id);io.to(d.map).emit('drop:remove',id)}for(const m of monsters.values()){if(!m.alive&&now>=m.respawnAt){m.alive=true;m.hp=m.maxHp;m.x=380+Math.random()*1850;m.y=100+Math.random()*1400;io.to(m.map).emit('monster',m)}else if(m.alive&&Math.random()<.18){m.x=Math.max(120,Math.min(2320,m.x+(Math.random()-.5)*18));m.y=Math.max(60,Math.min(1540,m.y+(Math.random()-.5)*18));io.to(m.map).emit('monster',m)}}},500);
http.listen(PORT,'0.0.0.0',()=>console.log(`HOKADIW Realms v0.4 server :${PORT}`));
